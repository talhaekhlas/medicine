<?php

Route::get('/', 'HomeController@investigation_summery');
